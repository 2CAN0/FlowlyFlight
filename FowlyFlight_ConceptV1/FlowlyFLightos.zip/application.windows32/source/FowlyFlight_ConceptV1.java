import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 
import ddf.minim.analysis.*; 
import ddf.minim.effects.*; 
import ddf.minim.signals.*; 
import ddf.minim.spi.*; 
import ddf.minim.ugens.*; 
import ddf.minim.*; 
import java.util.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class FowlyFlight_ConceptV1 extends PApplet {

// The Fowly Flight
// IG102-2







public void setup() {
  Sound = new Minim(this);
  menutheme = Sound.loadFile("menu1.mp3");
  jump = Sound.loadFile("jump.wav");
  bounce = Sound.loadFile("mJump.wav");
  hit = Sound.loadFile("Hit_Hurt.wav");
  coin_pickup = Sound.loadFile("Pickup_Coin.wav");
  gameOver = Sound.loadFile("gameOver1.mp3");
  explosion = Sound.loadFile("Explosion.wav");
  theme = Sound.loadFile("menu2.mp3");

  //size(1600, 900, P3D);
  
  noStroke();
  //noCursor();
  
  frameRate(60);
  background(30);
  mainSetup();
}

public void draw() {
  if (inMenu && !playGame & !inShop) {  
    menu.update();
    menu.draw();
  } else if (playGame && !inShop) {
    tint(255, 255);
    if (!bgSelected) {
      image(menu.fWall, 0,0,width, height);
      lvlS.update();
      lvlS.draw();
    } else {
      if (!dead.status) {
        background(30);
        drawWall();
        drawBuilding();
        enemyUpdate();
        player.update();
        playerLauncherUpdate();
        if (player.launched)
          player.draw();
        else{
           drawTutorial(); 
        }
        collectableUpdate();
        score.update();      
        score.draw();
        stamina.update();
        stamina.draw();
      } else {
        dead.draw();
        dead.update();
      }
    }
  } else if (inShop) {
    menuShop.update();
    menuShop.draw();
  }

  for (int iPs = systems.size() - 1; iPs > 0; iPs--) {
    ParticleSystem pls = systems.get(iPs);
    pls.run();
    if (pls.particles.size() == 0) {
      systems.remove(iPs);
    }
    if (extremeWeather && weatherOn) {
      pls.addRainDrop();
      //println("Added a new Rain Particle");
    }
  }

  if (devMode) {
    textAlign(RIGHT, TOP);
    textSize(20);
    if (frameRate < 55) {
      fill(255, 0, 0);
    } else {
      fill(255);
    }
    println("fps: "+ frameRate);
    text("fps: "+ frameRate, width, 0); 
    fill(255);
  }
}

public void keyPressed() {  
  if (keyCode < KEY_LIMIT) 
    keysPressed[keyCode] = true;
  if (inNameCreator && keyCode > 48 && keyCode < 90) {
    hs.nameC.chars[hs.nameC.selectedIndex].charCode = keyCode;
    hs.nameC.changed = true;
    hs.nameC.selectedIndex++;
    hs.nameC.chars[hs.nameC.selectedIndex - 1].selected = false;
  }
}

public void keyReleased() {
  if (keyCode < KEY_LIMIT)
    keysPressed[keyCode] = false;

  enterPressed = false;
  hs.changedSelected = false;

  if (inMenu) {
    menu.changedSelected = false;
  } else if (inShop) {
    menuShop.changedSelected = false;
  }

  hs.nameC.changed = false;
  lvlS.selectedChanged = false;
}
//Luca Ruiters - 500796991

PImage coinImg;
boolean hitShit = false;
float prevX;
float prevY;

class Collectables {
  float x, 
    y, 
    vx, 
    radius, 
    angle;
  int pickupTimer;


  Collectables(float velocityX, PImage co) {
    y = random(0, height/3*2 - radius);
    x = random(width, width + 100);
    vx = velocityX;
    radius = 50;
    timerStart();
    coinImg = co;
    angle = 0;
    pickupTimer = 60;
  }

  public void update() {
    x += vx;
    angle += 0.09f;
  }

  public void timerStart() {
    timer2.start();
  }

  public void timerStop() {
    timer2.stop();
  }

  public void draw() {
    if (hitDetected(player, coin)) {
      collectedCoins += 1;
      prevX = x;
      prevY = y;
      coin_pickup.rewind();
      coin_pickup.play();
      vx   = -10;
      x = 0 - radius;
      println("Coins: "+(int)collectedCoins);

      //Pickup feedback

      textAlign(CENTER, CENTER);
      textSize(15);
      fill(255);
      hitShit = true;
    } else {
      fill(0xffFFF158);
      image(coinImg, x-radius, y - radius, radius*2, radius*2);
      //println("X: "+x+ " Y:"+ y+" xVelocity: "+vx +" TimeElapsed: "+timer2.second());
    }
    
    if (hitShit && pickupTimer > 0) { 
      stroke(0);
        text("+ 10", prevX, prevY);
        noStroke();
        pickupTimer -= 1;
        println("snikkel");
      } else {
        pickupTimer = 60;
        hitShit = false;
      }
  }

  public boolean hitDetected(Player pl, Collectables coin) {
    float closeX = coin.x;
    float closeY = coin.y;

    if (coin.x < pl.x) closeX = pl.x;

    if (coin.x > pl.x) closeX = pl.x + pl.w;

    if (coin.y < pl.y) closeY = pl.y;

    if (coin.y > pl.y) closeY = pl.y + pl.h;

    float dX = closeX - coin.x;
    float dY = closeY - coin.y;

    float distance = sqrt((dX*dX)+(dY*dY));

    return (distance < coin.radius);
  }
}

public void collectableUpdate() {
  if (timer2.second() >= 10) {
    timer2.stop();
    coin.x = width + 100;
    coin.y = random(0, height);
    timer2 = new StopWatchTimer();
    timer2.start();
  }

  coin.update();
  coin.draw();
}
class GameOver {
  float x, 
    y, 
    tekst, 
    goWidth, 
    goHeight = 75, 
    goSpacing =120, 
    fontSize = 80;

  String text;
  boolean hover = false;
  boolean status = false;

  GameOver (float goX, float goY, float gameOverWidth, float gameOverHeight, String goText, float gameOverSpacing) {
    x = goX;
    y = goY;
    goWidth = gameOverWidth;
    goHeight = gameOverHeight;
    text = goText;
    goSpacing = gameOverSpacing;
  }

  public void draw() {
    noStroke();
    image(bg.maps[0], 0, 0, width, height );
  }

  public void update() {
    if (status) {
      if (!gameOverPlayer) {
        gameOver.rewind();
        gameOver.play();
        theme.pause();
      }
      hs.update(score.score);
      hs.draw();
    }
  }
}

public void restart() {
  enemyReset();
  hsUpdated = false;
  hs.nameC.nameSet = false;
  gameOverPlayer = false;
  enemies.add(new Enemy(30, 30, player.vx, plane));
  Buildings.clear();
  setupBuilding();
  player = new Player();
  setupWallLvlS(); 
  playerLauncher = new PlayerLauncher(canon);
  coin = new Collectables(player.vx, coinImg);
  collectedCoins = 0;
  setupScore();
  setupStamina();
}
class HighScore {
  Table scores;
  String fileLocation;
  int maxScores;
  PVector size;
  boolean restart = false;
  boolean changedSelected = false;
  int lastScore = 0;
  MiniMenu mm;
  NameCreater nameC;

  HighScore(String fL, int mS, float w, float h, NameCreater NC) {
    fileLocation = fL;
    maxScores = mS;
    try {
      scores = loadTable(fileLocation, "header"); 
      scores.getInt(0, 0);
      println("Table Loaded (HighScores)");
    } 
    catch (Exception ex) {
      println("!!!!!!Failed to load table we will create a new one!!!!!!!"); 
      println("Error: "+ex.getMessage());

      createTable();
    }
    size = new PVector(w, h);
    mm = new MiniMenu(opt);
    nameC = NC;
  }

  public void createTable() {
    scores = new Table();
    String[] devNames = {"2CAN0", "Frank", "Nino", "Mitch", "Jay", "Luca", "Alex", "John", "AAA", "AAA"};
    int[] plScores = {7000, 6000, 5000, 4000, 3000, 2000, 1000, 500, 250, 0};
    scores.addColumn("id");
    scores.addColumn("name");
    scores.addColumn("score");
    for (int iData = 0; iData < maxScores; iData++) {
      TableRow newRow = scores.addRow();
      newRow.setInt(0, iData);
      newRow.setString(1, devNames[iData]);
      newRow.setInt(2, plScores[iData]);
    }

    println("Table Created");
  }

  public void update(int s) {    
    int lowestScore = scores.getInt(scores.getRowCount() - 1, "score");
    lastScore = s;
    if (!nameC.nameSet && s >= lowestScore) {
      systems.clear();
      if (!inNameCreator)
        inNameCreator = true;

      nameC.update();
      nameC.draw();
    } else if (s < lowestScore && !nameC.nameSet) {
      nameC.nameSet = true;
    }

    if (!hsUpdated && nameC.nameSet) {
      sortTable(scores, s, name);
      hsUpdated = true;
      while (scores.getRowCount() > maxScores) {
        scores.removeRow(scores.getRowCount() - 1);
      }

      int iRow = 0;
      for (TableRow r : scores.rows()) {
        r.setInt(0, iRow);
        iRow++;
      }
      save();
    }
  }

  public void drawScores() {
    fill(0, 100);
    rect(width/2 - size.x/2, height/2 - size.y/1.5f, size.x, size.y);
    textAlign(CENTER, TOP);
    fill(255);
    textSize(30);
    text("Highscores", width/2, height/2 - size.y/1.5f + 15);
    int fontSize = 25;
    textSize(fontSize);
    float scoreY = height/2 - size.y/1.5f + fontSize*3.15f;
    for (int iScore = 0; iScore < scores.getRowCount(); iScore++) {
      textAlign(LEFT, CENTER);
      TableRow tr = scores.getRow(iScore);
      if (tr.getInt("score") == score.score && tr.getString("name") == name) {
        fill(255, 255, 0);
      } else {
        fill(255);
      }
      text((tr.getInt(0) + 1)+".", width/2 - size.x/2 + 10, scoreY);
      textAlign(CENTER, CENTER);
      text(tr.getString("name"), width/2, scoreY);
      textAlign(RIGHT, CENTER);
      text((int)Float.parseFloat(tr.getString("score")), width/2 + size.x/2 - 10, scoreY);

      scoreY += fontSize + fontSize/3;
    }
    
    fill(0, 100);
    rect(width/2 - size.x/2, height/2 + size.y/2.8f, size.x, 50);
    fill(255);
    textAlign(LEFT);
    text("score: ", width/2 - size.x/2 + 10, height/2.0f + size.y/2.4f + 11);
    textAlign(RIGHT);
    text(lastScore, width/2 + size.x/2 - 10, height/2.0f + size.y/2.4f + 11);
  }

  public void draw() {
    if (nameC.nameSet) {
      drawScores();
      mm.update();
      mm.draw();
    }
  }

  public void save() {
    try {
      saveTable(scores, fileLocation);
      println("Saved succesfully");
    } 
    catch (Exception ex) {
      println("Something went wrong while saving the table");
      println("Error: "+ex.getMessage());
    }
  }

  public void read() {
    for (TableRow r : scores.rows()) {
      println("ID: "+r.getInt(0)+"    Name: "+r.getString(1)+"    Score: "+ r.getDouble(2));
    }
  }

  public Table sortTable(Table t, double high, String nam) {
    TableRow previous;
    int hD = t.getInt(t.getRowCount() - 1, 0);
    String hN = nam;
    double hS = high;

    int d;
    String n;
    double s;

    for (int iRow = t.getRowCount() - 2; iRow >= 0; iRow--) {
      previous = t.getRow(iRow);
      d = previous.getInt(0);
      n = previous.getString(1);
      s = previous.getDouble(2);
      if (hS > s) {
        t.setInt(iRow, 0, hD);
        t.setString(iRow, 1, hN);
        t.setDouble(iRow, 2, hS);

        t.setInt(iRow + 1, 0, d);
        t.setString(iRow + 1, 1, n);
        t.setDouble(iRow + 1, 2, s);
      }
    }
    return t;
  }


  String[] opt = {"Play", "Main"};

  class MiniMenu {
    int AmountButtons;
    int selectedIndex = 0;
    int spacing = 30;

    String[] options;
    String gameName;
    ArrayList<Button> buttons = new ArrayList<Button>();

    MiniMenu(String[] text) {
      options = new String[text.length];
      options = text;

      AmountButtons = options.length;
      float tempW = 250;
      float tempH = 75;
      float tempX = width/2 - tempW * (AmountButtons/2);
      float tempY = height/2 + size.y/2;

      for (int iButton = 0; iButton < AmountButtons; iButton++) {
        if (iButton == 0) {
          buttons.add(new Button(tempX, tempY + tempH/2, tempW, tempH, options[iButton]));
          Button btn = buttons.get(0);
          btn.selected = true;
        } else {
          Button btn = buttons.get(iButton - 1);
          buttons.add(new Button(btn.location.x + tempW + spacing, tempY + tempH/2, tempW, tempH, options[iButton]));
        }
      }
    }

    public void update() {
      if (keysPressed[LEFT] && selectedIndex > 0 && !changedSelected) {
        selectedIndex--;
        Button btn1 = buttons.get(selectedIndex);
        btn1.selected = true;
        Button btn2 = buttons.get(selectedIndex + 1);
        btn2.selected = false;
        changedSelected = true;
      }

      if (keysPressed[RIGHT] && selectedIndex < options.length - 1 && !changedSelected) {
        selectedIndex++;
        Button btn1 = buttons.get(selectedIndex);
        btn1.selected = true;
        Button btn2 = buttons.get(selectedIndex - 1);
        btn2.selected = false;
        changedSelected = true;
      }

      if ((keysPressed[ENTER]) && !enterPressed) {
        enterPressed = true;
        Button btn = buttons.get(selectedIndex);
        if (btn.text == options[0]) {
          restart();
          drawLoading();
          test.starts += 1;
          gameOver.pause();
          theme.rewind();
          theme.play();
          rainChange();
        } else if (btn.text == options[1]) {
          restart();
          drawLoading();
          inMenu = true;
          bgSelected = false;
          playGame = false;
          gameOver.pause();
          menutheme.rewind();
          menutheme.play();
          if (testing) {
            test.stopTesting();
          }
        }
        dead.status = false;
      }
    }

    public void draw() {
      Button tBtn = buttons.get(0);
      for (int iButton = 0; iButton < AmountButtons; iButton++) {
        Button btn = buttons.get(iButton);
        btn.draw();
      }
    }

    class Button {
      PVector location, size;
      String text;
      boolean selected;

      Button(float x, float y, float w, float h, String info) {
        location = new PVector(x, y);
        size = new PVector(w, h);
        text = info;
      }

      public boolean mouseHover() {
        boolean x = (mouseX > location.x && mouseX < location.x + size.x);
        boolean y = (mouseY > location.y && mouseY < location.y + size.y);
        return (x && y);
      }

      public void draw() {
        if (selected) {
          fill(255, 50);
          stroke(255);
          strokeWeight(4);
          int mini = 4;
          //Left Upper
          line(location.x, location.y, location.x + size.y/mini, location.y);
          line(location.x, location.y, location.x, location.y + size.y/mini);

          //Left Lower
          line(location.x, location.y + size.y, location.x, location.y + size.y - size.y/mini);
          line(location.x, location.y + size.y, location.x + size.y/mini, location.y + size.y);

          //Right Upper
          line(location.x + size.x, location.y, location.x + size.x - size.y/mini, location.y);
          line(location.x + size.x, location.y, location.x + size.x, location.y + size.y/mini);

          //Right Lower
          line(location.x + size.x, location.y + size.y, location.x + size.x - size.y/mini, location.y+ size.y);
          line(location.x + size.x, location.y + size.y, location.x + size.x, location.y + size.y - size.y/mini);
        } else {
          fill(0, 100);
          noStroke();
        }

        noStroke();
        rect(location.x, location.y, size.x, size.y);
        fill(255);
        textSize(30);
        textAlign(CENTER, CENTER);
        text(text, location.x + size.x/2, location.y + size.y/2);
        noStroke();
      }
    }
  }
}
class LvlSelector {
  PVector location, size;
  PImage[] mapPreviews;
  String[] names;
  float margin;
  float btnSize;
  int selectedMap = 0;
  boolean selectedChanged = false;

  LvlSelector(PVector tempLocation, PVector tempSize, PImage[] tempPreviews, String[] tempNames, float tempMargin, float tempBtnSize) {
    location = tempLocation.copy();
    size = tempSize.copy();
    mapPreviews = tempPreviews;
    names = tempNames;
    margin = tempMargin;
    btnSize = tempBtnSize;
  }

  public void update() {
    if (keysPressed[RIGHT] && !selectedChanged) {
      if (selectedMap == mapPreviews.length - 1)
        selectedMap = 0;
      else 
      selectedMap++;

      selectedChanged = true;
    } else if (keysPressed[LEFT] && !selectedChanged) {
      if (selectedMap == 0)
        selectedMap = mapPreviews.length - 1;
      else
        selectedMap--;

      selectedChanged = true;
    }
    
    if((keysPressed[ENTER] || keysPressed[32]) && !enterPressed){
       enterPressed = true;
       bgSelected = true;
       drawLoading();
       bg = new Background(maps[selectedMap], mapImages[selectedMap]);
    }
  }

  public void draw() {
    //Map Name
    textSize(30);
    textAlign(CENTER);
    text(names[selectedMap], location.x + size.x/2, location.y - margin);
    text("Press Enter to select", location.x + size.x/2, location.y + size.y + ((height - (location.y + size.y))/2));
    textAlign(LEFT, TOP);

    //Buttons
    ////Left Button
    triangle(location.x - margin - btnSize, location.y + size.y/2, 
      location.x - margin, location.y + size.y/2 - btnSize/2, 
      location.x - margin, location.y + size.y/2 + btnSize/2);
    ////Right Button
    triangle(location.x + size.x + margin + btnSize, location.y + size.y/2, 
      location.x + size.x + margin, location.y + size.y/2 - btnSize/2, 
      location.x + size.x + margin, location.y + size.y/2 + btnSize/2);

    //Map Preview
    stroke(255);
    rect(location.x, location.y, size.x, size.y);
    image(mapPreviews[selectedMap], location.x, location.y, size.x, size.y);
    noStroke();
  }
}
//Luca Ruiters - 500796991
ArrayList<PImage> wall = new ArrayList<PImage>();

class Menu {
  int AmountButtons;
  int selectedIndex = 0;
  int spacing = 30;

  String[] options;
  ArrayList<Button> buttons = new ArrayList<Button>();
  boolean changedSelected = false;
  String gameName;
  ArrayList<PImage> wallpaper;
  PImage fWall;

  Menu(String[] text, String GN, ArrayList<PImage> img) {
    options = new String[text.length];
    options = text;

    gameName = GN;

    AmountButtons = options.length;
    float tempW = 250;
    float tempH = 85;
    float tempX = width/2;
    float tempY = height / 2 - tempH *(AmountButtons/2);

    wallpaper = img;
    fWall = wallpaper.get((int)random(0, wallpaper.size()));

    for (int iButton = 0; iButton < AmountButtons; iButton++) {
      if (iButton == 0) {
        buttons.add(new Button(tempX - tempW/2, tempY, tempW, tempH, options[iButton]));
        Button btn = buttons.get(0);
        btn.selected = true;
      } else {
        Button btn = buttons.get(iButton - 1);
        buttons.add(new Button(tempX - tempW/2, btn.location.y + tempH + spacing, tempW, tempH, options[iButton]));
      }
    }
  }

  public void update() {
    if (keysPressed[UP] && selectedIndex > 0 && !changedSelected) {
      selectedIndex--;
      Button btn1 = buttons.get(selectedIndex);
      btn1.selected = true;
      Button btn2 = buttons.get(selectedIndex + 1);
      btn2.selected = false;
      changedSelected = true;
    }

    if (keysPressed[DOWN] && selectedIndex < options.length - 1 && !changedSelected) {
      selectedIndex++;
      Button btn1 = buttons.get(selectedIndex);
      btn1.selected = true;
      Button btn2 = buttons.get(selectedIndex - 1);
      btn2.selected = false;
      changedSelected = true;
    }

    if ((keysPressed[ENTER] || keysPressed[32]) && !enterPressed) {
      drawLoading();
      enterPressed = true;
      Button btn = buttons.get(selectedIndex);
      if (btn.text == options[0]) {
        inMenu = false;
        playGame = true;
        menutheme.pause();
        theme.rewind();
        theme.play();

        if (testing) {
          test.startTesting(); 
          test.starts += 1;
        }

        rainChange();
      } else if (btn.text == options[1]) {
        inMenu = false;
        inShop = true;
      } else if (btn.text == options[2]) {
        exit();
      }
    }
  }

  public void draw() {
    image(fWall, 0, 0, width, height);
    Button tBtn = buttons.get(0);
    textFont(font, 100);
    textAlign(CENTER, CENTER);
    text(gameName, width/2, tBtn.location.y/2 - spacing);
    textAlign(TOP, LEFT);
    for (int iButton = 0; iButton < AmountButtons; iButton++) {
      Button btn = buttons.get(iButton);
      btn.draw();
    }
  }

  class Button {
    PVector location, size;
    String text;
    boolean selected;

    Button(float x, float y, float w, float h, String info) {
      location = new PVector(x, y);
      size = new PVector(w, h);
      text = info;
    }

    public boolean mouseHover() {
      boolean x = (mouseX > location.x && mouseX < location.x + size.x);
      boolean y = (mouseY > location.y && mouseY < location.y + size.y);
      return (x && y);
    }

    public void draw() {
      if (selected) {
        fill(255, 50);
        noStroke();
        rect(location.x, location.y, size.x, size.y);
        stroke(255);
        strokeWeight(4);
        int mini = 4;
        //Left Upper
        line(location.x, location.y, location.x + size.y/mini, location.y);
        line(location.x, location.y, location.x, location.y + size.y/mini);

        //Left Lower
        line(location.x, location.y + size.y, location.x, location.y + size.y - size.y/mini);
        line(location.x, location.y + size.y, location.x + size.y/mini, location.y + size.y);

        //Right Upper
        line(location.x + size.x, location.y, location.x + size.x - size.y/mini, location.y);
        line(location.x + size.x, location.y, location.x + size.x, location.y + size.y/mini);

        //Right Lower
        line(location.x + size.x, location.y + size.y, location.x + size.x - size.y/mini, location.y+ size.y);
        line(location.x + size.x, location.y + size.y, location.x + size.x, location.y + size.y - size.y/mini);
      } else {
        fill(0, 100);
        noStroke();
        rect(location.x, location.y, size.x, size.y);
      }

      fill(255);
      textFont(font, 30);
      textAlign(CENTER, CENTER);
      text(text, location.x + size.x/2, location.y + size.y/2);
    }
  }
}
/*
*@author: Luca Ruiters
*/

class NameCreater {
  PVector position;
  float size;
  int fontSize;
  int selectedIndex = 0;
  boolean changed = false;
  boolean nameSet = false;

  character[] chars;

  NameCreater(float amount) {
    position = new PVector(width/2, height/2);
    size = amount;
    chars = new character[(int)amount];
    fontSize = 40;
    for (int iChar = 0; iChar < size; iChar++) {
      if (iChar == 0) {
        try {
          chars[iChar] = new character(width/2 - size/2*fontSize, height/2, name.charAt(iChar));
        }
        catch (Exception ex) {
          chars[iChar] = new character(width/2 - size/2*fontSize, height/2, PApplet.parseChar('a'));
        }
      } else {
        character prChar = chars[iChar - 1];
        try {
          chars[iChar] = (new character(prChar.position.x + 5 + fontSize, height/2, name.charAt(iChar)));
        } 
        catch (Exception ex) {
          chars[iChar] = (new character(prChar.position.x + 5 + fontSize, height/2, PApplet.parseChar(' ')));
        }
      }
    }
  }

  public void update() {
    if (keysPressed[LEFT] && selectedIndex > 0 && !changed) {
      selectedIndex--;
      changed = true;
      character prevC = chars[selectedIndex + 1];
      prevC.selected = false;
    }
    if (keysPressed[RIGHT] && selectedIndex < size - 1 && !changed) {
      selectedIndex++;
      changed = true;
      character prevC = chars[selectedIndex - 1];
      prevC.selected = false;
    }

    if (keysPressed[ENTER] || keysPressed[32] && !enterPressed) {
      enterPressed = true;
      nameSet = true;
      name = "";
      for (character t : chars) {
        name += PApplet.parseChar(t.charCode);
      }
      inNameCreator = false;
    } else {   
      character c = chars[selectedIndex];
      c.selected = true;
      c.update();
    }
  }

  public void draw() {
    for (int iChar = 0; iChar < size; iChar++) {
      character c = chars[iChar];
      c.draw();
    }

    fill(255);
    stroke(255);
    textAlign(CENTER, CENTER);
    text("You got into the top 10", width/2, height/5);
    text("Press Enter to continue", width/2, height/5*4);
    textAlign(TOP, LEFT);
  }

  class character {
    int charCode;
    PVector position;
    boolean selected = false;

    character(float x, float y, char d) {
      charCode = PApplet.parseChar(d);
      position = new PVector(x, y);
    }

    public void update() {
      if (selected) {
        if (keysPressed[DOWN] && charCode > 48 && !changed) {
          charCode++;
          changed = true;
        }
        if (keysPressed[UP] && charCode < 90 && !changed) {
          charCode--;
          changed = true;
        }
      }
    }

    public void draw() {      
      if (selected) {
        fill(255, 100);
        rect(position.x, position.y - fontSize*1.5f, fontSize, fontSize*1.5f);
      }

      fill(255);
      stroke(255);
      line(position.x, position.y, position.x + fontSize, position.y);
      textSize(fontSize);
      textAlign(LEFT, BOTTOM);
      text(PApplet.parseChar(charCode), position.x, position.y);
    }
  }
}
class ParticleSystem {

  ArrayList<Particle> particles;    // An arraylist for all the particles
  PVector origin, velocity, size;
  float wind, gravity, lifespan;// An origin point for where particles are birthed
  float factor;
  String type;

  ParticleSystem(int num, PVector l, PVector v, PVector s, float w, float g, float ls, String typo) {
    particles = new ArrayList<Particle>();   // Initialize the arraylist
    origin = l.copy();                        // Store the origin point
    size = s.copy();
    wind = w;
    gravity = g;
    lifespan = ls;
    type = typo;
    for (int i = 0; i < num; i++) {
      if (type.toLowerCase() == "simple")
        particles.add(new Particle(origin, lifespan, wind, gravity, new PVector(random(-1, 1), random(-1, 1)), size));    // location, lifespan, wind, gravity, velocity, size
    }
  }

  //Constructer for the Feather PS
  ParticleSystem(int num, PVector l, PVector v, PVector s, float w, float g, float ls, String typo, PImage feat) {
    particles = new ArrayList<Particle>();   // Initialize the arraylist
    origin = l.copy();                        // Store the origin point
    size = s.copy();
    wind = w;
    gravity = g;
    lifespan = ls;
    type = typo;
    for (int i = 0; i < num; i++) {
      particles.add(new FeatherParticle(origin, lifespan, wind, gravity, new PVector(random(-1, 1), random(-1, 1)), size, feat));    // location, lifespan, wind, gravity, velocity, size, image
    }
  }


  //Constructer for the rain PS
  ParticleSystem(int num, PVector l, PVector v, PVector s, float w, float g, float ls, String typo, float angle) {
    particles = new ArrayList<Particle>();   // Initialize the arraylist
    origin = new PVector(random(0, width + height), l.y);                        // Store the origin point
    velocity = v.copy();
    size = s.copy();
    wind = w;
    gravity = g;
    lifespan = ls;
    type = typo;
    factor = 100f;
    for (int i = 0; i < num; i++) {
      particles.add(new RainParticle(origin, lifespan, random(player.vx)/factor, gravity, velocity, size, angle));    // location, lifespan, wind, gravity, velocity, size
    }
  }

  public void run() {
    // Cycle through the ArrayList backwards, because we are deleting while iterating
    for (int i = particles.size()-1; i >= 0; i--) {
      Particle p = particles.get(i);
      p.run();
      if (p.isDead()) {
        particles.remove(i);
      }
    }
  }

  public void addRainDrop() {
    particles.add(new RainParticle(origin, lifespan, random(player.vx)/factor, gravity, velocity, size, 0));
  }

  public void addParticle() {
    Particle p;
    // Add either a Particle or CrazyParticle to the system
    if (extremeWeather) {
      p = new RainParticle(origin, lifespan, wind, gravity, velocity, size, 0);
    } else
      p = new Particle(origin, lifespan, wind, gravity, new PVector(random(-1, 1), random(-1, 1)), size);
    particles.add(p);
  }

  public void addParticle(Particle p) {
    particles.add(p);
  }

  // A method to test if the particle system still has particles
  public boolean dead() {
    return particles.isEmpty();
  }
}

class FeatherParticle extends Particle {
  PImage feather;
  float angle;

  FeatherParticle(PVector l, float span, float wind, float gravity, PVector v, PVector s, PImage f) {
    super(l, span, wind, gravity, v, s);
    feather = f;
    angle =  atan(v.y/v.x);
  }

  public void update() {
    super.update();
    lifespan -= 0.02f;
    angle += 0.02f;
  }

  public void display() {
    pushMatrix();
    translate(position.x, position.y);
    tint(255, lifespan);
    rotate(angle);
    //fill(255, lifespan);
    image(feather, 0, 0, size.x, size.y);
    popMatrix();
  }
}

//Systeem om te kiezen of regent of niet.
public void rainChange() {
  int wrmWerktNiet = (int)Math.floor(random(0, 5) % 2);
  if ( wrmWerktNiet == 0) {
    systems.add(new ParticleSystem(MAX_RAINPARTS, new PVector(width/2, -rainSize.y), rainVelo, rainSize, rainWind, rainGravity, rainSpan, "Rain", 0));
    extremeWeather = true;
    println("it should rain now");
  } else {
    systems.clear();
    extremeWeather = false;
    println("The weather forecast is sunny atm");
  }
}

class RainParticle extends Particle {
  float angle;
  RainParticle(PVector l, float span, float wind, float gravity, PVector v, PVector s, float r) {
    super(l, span, wind, gravity, v, s); //l - location; v - velocity; s - size;
    position = new PVector(random(-10, width + height), random(-10, 0));
    lifespan = 600;
    angle = r;
    //velocity.x = -5;
  }

  public void update() {
    super.update(); 
    angle += random(0.01f);
  }

  public void display() {
    if (weatherOn) {
      pushMatrix();
      translate(position.x, position.y);
      stroke(39, 171, 240, lifespan);
      rotate(angle);
      line(0, 0, 25, 0);
      popMatrix();
    }
  }
}

class Particle {
  PVector position, 
    velocity, 
    acceleration, 
    size;
  float lifespan;

  Particle(PVector l, float span, float wind, float gravity, PVector v, PVector s) {
    acceleration = new PVector(wind, gravity);
    velocity = new PVector(random(-1, 1), random(-1, 1));
    position = l.copy();
    lifespan = span;
    size = s.copy();
  }

  public void run() {
    update();
    display();
  }

  // Method to update position
  public void update() {
    velocity.add(acceleration);
    position.add(velocity);
    lifespan -= 2.0f;
  }

  // Method to display
  public void display() {
    noStroke();
    fill(255, lifespan);
    ellipse(position.x, position.y, size.x, size.y);
  }

  // Is the particle still useful?
  public boolean isDead() {
    return (lifespan < 0.0f);
  }
}
// Alex

class Stamina {
  float staminaBarX, staminaBarY, staminaLevel, staminaMax, staminaHeight, staminaBarClr, staminaWidth;
  int staminaDrain, staminaRegen;

  Stamina(Score sc) {
    staminaBarX = sc.w;
    staminaBarY = 0;
    staminaMax = width - sc.w;
    staminaWidth = staminaLevel;
    staminaHeight = 30;
    staminaBarClr = color(0, 255, 0);
    staminaDrain = 5;
    staminaRegen = 1;
    staminaLevel = staminaMax;
  }

  public void update() {
    if (keysPressed[32] && player.launched == true && staminaLevel > 0 || keysPressed[ENTER] && player.launched == true && staminaLevel > 0) {
      staminaLevel -= staminaDrain;
    } else {
      if (staminaLevel < staminaMax) {
        staminaLevel += staminaRegen;
      }
    }
  }

  public void draw() {
    stroke(255);
    fill(0, 0);
    rect(staminaBarX, staminaBarY, staminaMax, staminaHeight);
    fill(0, 255, 0);
    rect(staminaBarX, staminaBarY, staminaLevel, staminaHeight);

    textAlign(LEFT, CENTER);
    textSize(20);
    fill(0);
    text("stamina", staminaBarX + 3, staminaHeight / 2);
  }
}

public void setupStamina() {
  stamina = new Stamina(score);
}
class StopWatchTimer {
  int startTime = 0, stopTime = 0;
  boolean running = false;  


  public void start() {
    startTime = millis();
    running = true;
  }

  public void stop() {
    stopTime = millis();
    running = false;
  }

  public int getElapsedTime() {
    int elapsed;
    if (running) {
      elapsed = (millis() - startTime);
    } else {
      elapsed = (stopTime - startTime);
    }
    return elapsed;
  }

  public int second() {
    return (getElapsedTime() / 1000) % 60;
  }

  public int minute() {
    return (getElapsedTime() / (1000*60)) % 60;
  }

  public int hour() {
    return (getElapsedTime() / (1000*60*60)) % 24;
  }
}
// "Press SPACE to launch and gain altitude"
class Tutorial {
  PVector position, size;
  float ttlSpacing = 120;

  String text;
  boolean hover = false;
  boolean grow = false;
  float minSize;
  float maxSize;
  float xShrink;
  float yShrink;
  PImage button;

  Tutorial (float ttlX, float ttlY, String ttlTextTutorial, float titleSpacing, PImage btn, float ttlW, float ttlH) {
    position = new PVector(ttlX, ttlY);
    size = new PVector(ttlW, ttlH);
    text = ttlTextTutorial;
    ttlSpacing = titleSpacing;

    minSize = size.x - .12f;
    maxSize = size.x + .12f;
    xShrink = minSize/size.x;
    yShrink = size.y - 5/size.y;

    button = btn;
  }

  public void changeSize() {
    float dim = 120;
    if (!grow) {
      if (size.x > minSize) {
        size.y -= yShrink/dim;
        size.x -= xShrink/dim;
      } else
        grow = true;
    } else {
      if (size.x < maxSize) {
        size.y += yShrink/dim;
        size.x += xShrink/dim;
      } else
        grow = false;
    }
  }

  public void draw() {
    textAlign(CENTER, CENTER);
    textFont(tutText);
    textSize(50);
    fill(255); //RGB
    text(text, position.x, height/4 - 60);
    changeSize();
    image(button, position.x - ttlW/2, position.y, size.x, size.y);
    textFont(font);
  }
}

public void setupTutorial() {
  ttlTutorial = new Tutorial(width/2, height/4, "To Gain Altitutde", 40, spaceBar, ttlW, ttlH);
}

public void drawTutorial() {
  fill(255);
  ttlTutorial.draw();
}
class Testing {
  Table time;
  String fileLocation;
  int starts;
  StopWatchTimer playTime = new StopWatchTimer(); 

  Testing(String fLocation) {
    fileLocation = fLocation;
    try {
      time = loadTable(fileLocation, "header"); 
      time.getInt(0, 0);
      println("Table Loaded");
    } 
    catch (Exception ex) {
      println("!!!!!!Failed to load table we will create a new one!!!!!!!"); 
      println("Error: "+ex.getMessage());

      createTable();
    }
  }

  public void createTable() {
    time = new Table();

    time.addColumn("id");
    time.addColumn("round time");
    time.addColumn("restarts");
    time.addColumn("average time");
    println("Table Created");
  }

  public void startTesting() {
    playTime.start();
  }

  public void stopTesting() {
    playTime.stop();
    TableRow newResults = time.addRow();
    newResults.setInt(0, time.getRowCount());
    newResults.setString(1, playTime.minute() + ":"+((float)playTime.getElapsedTime() / 1000 - (60 * (playTime.getElapsedTime() / (1000*60)) % 60))); //PlayTime in miliseconds
    newResults.setInt(2, starts);
    newResults.setString(3, ((playTime.getElapsedTime()/starts / (1000*60)) % 60) + ":" + ((float)playTime.getElapsedTime()/starts / 1000 - (60 * (playTime.getElapsedTime()/starts / (1000*60)) % 60)));
    try {
      saveTable(time, fileLocation);
      println("Table Saved");
    }
    catch (Exception ex) {
      println("Failed to save table!!\nError: "+ex.getMessage());
    }      
    playTime = new StopWatchTimer();
    starts = 0;
  }
}
final int KEY_LIMIT = 1024;
final int MAX_SCORES = 10;
boolean[] keysPressed = new boolean[KEY_LIMIT];
boolean hsUpdated = false;
boolean enterPressed = false;
String hsLocation = "data/highScore.csv";
String name = "AAA";

Player player;
PlayerLauncher playerLauncher;
Collectables coin;
Tutorial ttlTutorial;
GameOver dead;
Stamina stamina;
HighScore hs;
Animation blueBird;
NameCreater nameCreater;


/////DEV-MODE BEVAT coole en rare mechanics xD//////
boolean devMode = false;
boolean weatherOn = false;
////////////////////////////////////////////////////

///////Testing/////////
String testFileLocation = "data/testData.csv";
boolean testing = false;
Testing test;
///////////////////////

PFont font;
float defaultOverallVX;
float playerTotalStam;
float totalPlayerVx;
PImage wallpaper;

//Level Selector
LvlSelector lvlS;
PVector lvlSLocation, lvlSPrevSize;
float lvlSMargin = 20.0f;
float lvlSBtnSize = 50;

//Background
Background bg;
String[] mapNames = {"jungle", "mountain", "beach", "day", "night", "gray"};
int[] mapImages = {1, 1,1,1, 1, 1}; //MAX_IMAGES is 5
PImage[][] maps = new PImage[mapNames.length][5];
PImage[] mapPreviews = new PImage[mapNames.length];

//Particle System
ArrayList<ParticleSystem> systems = new ArrayList<ParticleSystem>();

//Weather Particle
PVector rainSize = new PVector(25, 25);
PVector rainVelo = new PVector(random(-1, -0.0002f), random(0, 1));
final int MAX_RAINPARTS = 50;
float rainWind = 0.05f;
float rainGravity = 0.05f;
float rainSpan = 255;
boolean extremeWeather;

//Feather Particle
PImage feather;
PVector featSize = new PVector(80, 50);
PVector featVelo = new PVector(random(-1, 1), random(-1, 1));
final int MAX_FEATPARTS = 10;
float featWind = 0.01f;
float featGravity = 0;
float featSpan = 255;

//Audio
Minim Sound;
AudioPlayer menutheme;
AudioPlayer jump;
AudioPlayer bounce;
AudioPlayer hit;
AudioPlayer coin_pickup;
AudioPlayer gameOver;
AudioPlayer explosion;
AudioPlayer theme;
boolean gameOverPlayer = false;

//Menu
Menu menu;
String gameName = "Fowly Flight";
String[] options = {"Play", "Shop", "Exit"};
boolean inMenu = true;
boolean playGame = false;
boolean inShop = false;
boolean bgSelected = false;

//Player
PImage canon;

//Shop menu
ShopMenu menuShop;

//Collectables
float collectedCoins = 0;
StopWatchTimer timer2;

String[] coinNames = {"coin_.png"};
PImage[] coinImages = new PImage[coinNames.length];
Animation[] coinA = new Animation[coinNames.length];

//Enemies


///Enemy Buildings
final int MAX_BUILDINGS = 2;
String[] buildingNames = {"Gebouw.png"};
PImage[] buildingImages = new PImage[buildingNames.length];

///Enemy Airplane
StopWatchTimer timer;
float enemiesCount = 1, 
  spawn = (random(5, 8));
PImage plane;
float planeWidth = 100;
float planeHeight = 50;

//Character Shop
String[] characterNames = {"ducky_", "gunther_", "owliver_", "wally_", "monsieurMallard_"};
int[] characterFrames = {2, 4, 7, 3, 4};
Animation[] characters = new Animation[characterNames.length];
int selectedCharacter = 0;

//Score
Score score;
float scoreWidth = 200;
long prev;

//Tutorial
PImage spaceBar;
PFont tutText;
float ttlH = 160;
float ttlW = 340;


//nameCreator
boolean inNameCreator = false;

public void mainSetup() {
  //Test
  test = new Testing(testFileLocation);

  //NameCreater
  nameCreater = new NameCreater(6);

  //Wallpaper
  wall.add(loadImage("Sprites/backGround.png"));
  wall.add(loadImage("Sprites/backGround2.png"));

  //Collectables
  timer2 = new StopWatchTimer();

  coinImg = loadImage("Sprites/coin_0.png");

  //Enemies
  timer = new StopWatchTimer();
  plane = loadImage("Sprites/plane.png");

  for (int iBuilding = 0; iBuilding < buildingNames.length; iBuilding++) {
    buildingImages[iBuilding] = loadImage("Sprites/"+buildingNames[iBuilding]);
  }

  //Particle
  feather = loadImage("Sprites/feather.png");

  //General
  player = new Player();
  hs = new HighScore(hsLocation, MAX_SCORES, 350, 400, nameCreater);
  canon = loadImage("Sprites/canon.png");
  playerLauncher = new PlayerLauncher(canon);
  coin = new Collectables(player.vx, coinImg);
  playerTotalStam = player.vx;
  totalPlayerVx = player.vx;
  dead = new GameOver(width/2, height/2 - 40, 225, 100, "OMG You dieded!\n\n Press A to restart", 30);
  menu = new Menu(options, gameName, wall);

  for (int iChar = 0; iChar < characterNames.length; iChar++) {
    characters[iChar] = new Animation(characterNames[iChar], characterFrames[iChar]);
  }

  menuShop = new ShopMenu(wall, characters);

  //player
  blueBird = new Animation(characterNames[selectedCharacter], 2);

  //Tutorial
  spaceBar = loadImage("Sprites/spaceBar.png");
  tutText = loadFont("tutFont.vlw");

  enemies.add(new Enemy(planeHeight, planeWidth, 10, plane));
  font = loadFont("data/8BIT.vlw");
  setupBuilding();
  setupWallLvlS(); //Setup for wall and level selector (backDrop tab) 
  setupScore();
  setupTutorial();
  setupStamina();
}

public void setupWallLvlS() {             
  for (int iImage = 0; iImage < mapNames.length; iImage++) {      
    //Setting the mapPreview
    mapPreviews[iImage] = loadImage("data/maps/"+mapNames[iImage]+"_0.png");

    for (int j = 0; j < mapImages[iImage]; j++) {
      maps[iImage][j] = loadImage(("data/maps/"+mapNames[iImage]+"_"+j+".png"));
    }
  }

  lvlSPrevSize = new PVector(width/3, height/3);
  lvlSLocation = new PVector(width/2 - lvlSPrevSize.x/2, height/2 - lvlSPrevSize.y/2);
  lvlS = new LvlSelector(lvlSLocation, lvlSPrevSize, mapPreviews, mapNames, lvlSMargin, lvlSBtnSize);
}

public void drawLoading() {
  textSize(30);
  textAlign(RIGHT);
  text("Loading", width - 50, height - 30);
}
class Animation {
  PImage[] images;
  int imageCount;
  int frame;
  int fps = 12;

  Animation(String imagePrefix, int count) {
    imageCount = count;
    images = new PImage[imageCount];

    for (int i = 0; i < imageCount; i++) {
      // Use nf() to number format 'i' into four digits
      String filename = "Sprites/"+imagePrefix + i +".png";
      images[i] = loadImage(filename);
    }
  }

  public void display(float xpos, float ypos, float w, float h) {
    if (frameCount % fps == 0)
      frame = (frame+1) % imageCount;
    image(images[frame], xpos, ypos, w, h);
  }

  public int getWidth() {
    return images[0].width;
  }
}
class Background {
  PImage[] maps;
  PVector[] position;
  int selectedMap = 0;
  int selectedMapImg = 0;
  int wallWidth;

  Background(PImage[] tempMaps, int imgCount) {
    wallWidth = width + 10;     

    if (imgCount == 1) {
      maps = new PImage[3];
      maps[0] = (tempMaps[0]);
      maps[1] = (tempMaps[0]);
      maps[2] = (tempMaps[0]);
      imgCount = 3;
    } else {
      maps = tempMaps;
    }

    position = new PVector[imgCount];
    for (int iPos = 0; iPos < position.length; iPos++) {
        position[iPos] = new PVector(iPos * wallWidth, 0);
    }
  }

  public void update(Player pl) {
    for (int iWall = 0; iWall < position.length; iWall++) {
      if (position[iWall].x + wallWidth < 0) {
        int prevPos = (iWall > 0)?iWall - 1: position.length - 1;
        position[iWall].x = position[prevPos].x + wallWidth;
      }

      position[iWall].x += pl.vx/3;
      println("Updating wall #"+iWall);
    }
  }

  public void draw() {
    for (int iWall = 0; iWall < position.length; iWall++) {
      noStroke();
      image(maps[iWall], position[iWall].x, position[iWall].y, wallWidth, height);
    }
  }
}

public void drawWall() {
  bg.update(player);
  bg.draw();
}
// Alexander & Nino & Luca

class ShopMenu {
  PImage fWall;
  boolean changedSelected = false;
  Animation[] characters;

  int arrowLeftPosX, arrowLeftPosY, arrowRightPosX, arrowRightPosY, arrowWidth, arrowHeight;

  ShopMenu (ArrayList<PImage> wall, Animation[] skins) {
    fWall = wall.get((int)random(0, wall.size()));
    characters = skins;

    // Arrows
    arrowLeftPosX = 608;
    arrowLeftPosY = 561;
    arrowRightPosX = 1312;
    arrowRightPosY = 561;
    arrowWidth = 46;
    arrowHeight = 48;
  }

  public void buttons() {
    fill(255);
    triangle (arrowLeftPosX, arrowLeftPosY, arrowLeftPosX + arrowWidth, arrowLeftPosY - arrowHeight, arrowLeftPosX + arrowWidth, arrowLeftPosY + arrowHeight);                // TODO - geen magic numbers!
    triangle (arrowRightPosX, arrowRightPosY, arrowRightPosX - arrowWidth, arrowRightPosY - arrowHeight, arrowRightPosX - arrowWidth, arrowRightPosY + arrowHeight);             // TODO - geen magic numbers!

    fill(0, 120);
    rect(width / 4, height / 4 * 3, width / 2, 50);         // TODO - geen magic numbers!
    textAlign(CENTER, CENTER);
    textSize(30);
    fill(255);
    text("Press ENTER to purchase or select", width / 2, height / 4 * 3 + 25);    // TODO - geen magic numbers!
  }

  public void update() {
    if ((keysPressed[ENTER] || keysPressed[32]) && !enterPressed) {
      inShop = false;
      inMenu = true;
      enterPressed = true;
    }

    if (keysPressed[RIGHT] && !changedSelected && selectedCharacter < characters.length - 1) {
      selectedCharacter++;
      changedSelected = true;
    } else if (keysPressed[LEFT] && !changedSelected && selectedCharacter > 0) {
      selectedCharacter--;
      changedSelected = true;
    }
  }

  public void draw() {
    image(fWall, 0, 0, width, height);
    float grow = 2;
    characters[selectedCharacter].display(width/2 - player.w/2*grow, height/2 - player.h/2*grow, player.w*grow, player.h*grow);  
    buttons();
  }
}
class EnemyBuilding {
  float x, 
    y, 
    h, 
    w, 
    vx;
  PImage img;

  EnemyBuilding(PImage[] imgList) {
    h = random(50, height/3);
    w = random(200, 300);
    x = random(width, width + 300);
    y = height - h;
    vx = random(-15, -5);
    img = imgList[(int)Math.floor(random(0, imgList.length))];
  }

  public void Move(Player pl) {
    if (x + w > 0) {
      x += vx;
    } else {
      h = random(75, height/5*2);
      w = random(200, 300);
      x = random(width, width + 300);
      y = height - h;
      vx = random(pl.vx/1.5f, pl.vx);
    }
  }

  public boolean hitDetected(Player p, EnemyBuilding e) {
    // Als y2Onder groter is dan y1onder en y2Onder kleiner is dan y1Boven licht de het linker onder hoek er tussen
    // Als y2Boven groter is dan y1Boven en kleinder is dan y1Onder licht de linker onder hoek in er tussen
    boolean x = ((p.x > e.x && p.x < e.x + e.w) ||(p.x + p.w > e.x && p.x + p.w < e.x + e.w));
    boolean y = ((p.y > e.y && p.y < e.y + e.h) || (p.y + p.h > e.y && p.y + p.h < e.y + e.h));
    return (x && y);
  }

  public void update(Player pl) {
    if (hitDetected(player, this)) {
      println("You hit a flying enemy!!");
      if (!devMode)
        dead.status = true;
      else {
        //
      }
    } else {
      Move(pl);
    }

    //if (hitDetection(x - player.radius, y - player.radius, x + player.radius, y + player.radius, player.x - player.radius, player.y - player.radius, player.x + player.radius, player.y + player.radius)) {
    //  println("You hit a building. What were you thinking!!");
    //  dead.status = true;
    //} else {
    //  Move();
    //}
  }

  public void draw() {
    fill(255, 200);
    image(img, x, y, w, h);
    if (devMode) {
      fill(0, 0);
      stroke(255, 0, 0);
      rect(x, y, w, h);
      noStroke();
    }
  }
}

ArrayList<EnemyBuilding> Buildings = new ArrayList<EnemyBuilding>();

public void drawBuilding() {
  if (player.vx != 0) {
    for (int iBuilding = 0; iBuilding < Buildings.size(); iBuilding++) {
      EnemyBuilding building = Buildings.get(iBuilding);
      building.update(player);
      building.draw();
    }
  }
}

public void setupBuilding() {
  for (int iBuilding = 0; iBuilding < MAX_BUILDINGS; iBuilding++) {
    EnemyBuilding building = new EnemyBuilding(buildingImages);
    building.draw();
    Buildings.add(building);
  }
}
//mitchell

// Enemy vliegtuig class
class Enemy {
  float x, 
    y, 
    vx, 
    w, 
    h, 
    x2, 
    y2;

  int r, 
    g, 
    b;

  boolean timerRunning = false;
  boolean hitDetected;
  PImage plane;

  Enemy(float enemyHeight, float enemyWidth, float xVelocity, PImage pImg) {
    h = enemyHeight;
    w = enemyWidth;
    x = random(width, width + 100); 
    y = random(0, height/3 - h);
    x2 = x + enemyWidth;
    y2 = y + enemyHeight;
    vx = xVelocity;

    r = (int)random(0, 256);
    g = (int)random(0, 256);
    b = (int)random(0, 256);

    startTimer();
    plane = pImg;
  }

  public void startTimer() {
    timer.start();
    timerRunning = true;
  }

  public void stopTimer() {
    timer.stop();
    enemiesCount++;
    timerRunning = false;
  }

  public void update() {    
    if (x + w > 0) {
      x -= vx;
    } else {
      x = random(width, width + 100); 
      y = random(0, height/3 + height/3 - h);
      hitDetected = false;
    }


    if (hitDetection(player, this)) {
      println("You hit a flying enemy!!");
      if (!devMode)
        dead.status = true;
      else {
        hitDetected = true;
      }
    }

    //if (hitDetection(x, y, player.x, player.y, x + w, y + h, player.x + player.radius*2, player.y + player.radius*2 )) {
    //  println("You hit a flying enemy!!");
    //  if (!devMode)
    //    dead.status = false;
    //  else {
    //    hitDetected = true;
    //  }
    //} 

    if (devMode) {
      fill(0, 0);
      stroke(255, 0, 0);
      rect(x, y, w, h);
      noStroke();
    }
  }


  public boolean hitDetection(Player p, Enemy e) {
    // Als y2Onder groter is dan y1onder en y2Onder kleiner is dan y1Boven licht de het linker onder hoek er tussen
    // Als y2Boven groter is dan y1Boven en kleinder is dan y1Onder licht de linker onder hoek in er tussen
    boolean x = ((p.x > e.x && p.x < e.x + e.w) ||(p.x + p.w > e.x && p.x + p.w < e.x + e.w));
    boolean y = ((p.y > e.y && p.y < e.y + e.h) || (p.y + p.h > e.y && p.y + p.h < e.y + e.h));
    return (x && y);
  }

  public void draw() {
    if (hitDetected)
      fill(0xff25A599);
    else
      fill(255);

    image(plane, x, y, w, h);
  }
}

public void enemyReset() {
  enemies.clear();
  enemiesCount = 1;
}

public void enemyUpdate() {
  if (player.vx != 0) {
    if (timer.second() >= spawn) {
      timer.stop();
      enemiesCount++;
      enemies.add(new Enemy(planeHeight, planeWidth, random(5, 15), plane));
      spawn = random(5, 8);
      timer = new StopWatchTimer();
      timer.start();
    }

    for (int iEnemy = 0; iEnemy <  enemiesCount; iEnemy++) {
      Enemy en = enemies.get(iEnemy);
      en.update(); 
      en.draw();
    }
  }
}

ArrayList<Enemy> enemies = new ArrayList<Enemy>();
// Alexander

class Player {
  float x, y;
  float vx, vy, gravity;
  float w, h;
  int clr;
  float bounceFriction, airFriction, flappingPower, bounceFrictionModifier, airFrictionModifier;
  boolean hitGround, launched;

  Player() {
    x = width/4;
    y = height/2;
    vx = 0;
    vy = 0;
    gravity = 1.2f;
    w = 140;
    h = 80;
    clr = color(255, 0, 0);
    bounceFriction = 0.5f;
    airFriction = 0;
    flappingPower = 2.5f;
    bounceFrictionModifier = 2;
    airFrictionModifier = 0.05f;
    hitGround = false;
    launched = false;
    x -= w;
    y -= h;
  }

  public void update() {
    // Velocity
    y += vy;


    // Fligth enabler
    if (y >= height / 4 * 3) {
      hitGround = true;
    } else {
      hitGround = false;
    }

    // "Stop sinking please" function
    if (y + h > height) {
      jump.rewind();
      jump.play();
      y = height - h;
      systems.add(new ParticleSystem(MAX_FEATPARTS, new PVector(x, y + h/2), featVelo, featSize, featWind, featGravity, featSpan, "feather", feather));
    }

    // Gravity & Air Friction funtion
    if (y + h <= height && launched) { 
      vy += 0.5f * gravity;
      vx += airFriction * airFrictionModifier;
    }

    if (vy > 0 && vx < 0) { // When losing altitude
      vx -= (0.6f * airFrictionModifier);
    }

    if (vy < 0 && vx < 0) { // When gaining altitude
      vx += airFrictionModifier;
    }

    // Bouncing function
    // Floor
    if (vx < 0) {
      if (y >= height - h) {
        vy -= bounceFriction;
        vy *= -1;
        vx += (bounceFriction * bounceFrictionModifier);
      }
    } else {
      vx = 0; 
      coin.vx = 0;
    }

    // Ceiling
    if (y <= 0) {
      y = 0;
      vy = 0.5f;
      systems.add(new ParticleSystem(MAX_FEATPARTS, new PVector(x, y - h/2), featVelo, featSize, featWind, featGravity, featSpan, "feather", feather));
    }

    // "Flapping" function
    if (keysPressed[32] && stamina.staminaLevel > 0 && !hitGround && vx < 0 || keysPressed[ENTER] && stamina.staminaLevel > 0 && !hitGround && vx < 0) {
      vy -= flappingPower;
    }

    //vx == 0 functie [DEATHSCREEN]
    if (vx == 0 && launched == true) {
      stamina.staminaLevel = 0;
      if (y == height - h) {
        dead.status = true;
      }
    }
  }

  public void draw() {
    fill(clr);
    characters[selectedCharacter].display(x, y, w, h);
    if (devMode) {
      fill(0, 0);
      stroke(255, 0, 0);
      rect(x, y, w, h);
    }
  }
}
// Alexander

class PlayerLauncher {
  float x, y, w, h, vx, rotation, launchSpeed, speedVariable, angle;
  int gameState;
  PImage canon;

  PlayerLauncher (PImage ca) {
    x = width/3;
    w = 400;
    h = 400;
    y = height/2;
    vx = 0;
    rotation = (PI/2.5f);
    launchSpeed = -20; // Negative to go 'forward'. Positive numbers will not work propperly.
    speedVariable = 2;
    gameState = 0;
    canon = ca;
    angle = 0;
  }

  public void launcherAparatus() {
    if (!player.launched)
      angle += 0.02f;
    else
      angle = 0;
    pushMatrix();
    fill (0);
    stroke(255);
    y += sin(angle *2) * 1.5f;
    x += cos(angle*1.5f) * 1;
    translate(x, y);
    rotate(PI/rotation);

    image(canon, 0, 0, w, h);
    popMatrix();
    noStroke();
  }

  public void update() {
    if (keysPressed[32] && !player.launched && !enterPressed) {
      //systems.add(new ParticleSystem(MAX_FEATPARTS, new PVector(x, y - h/2), featVelo, featSize, featWind, featGravity, featSpan, "feather", feather));
      player.vx = launchSpeed * speedVariable; // Player speed assign!
      coin.vx = player.vx;
      player.launched = true;
      explosion.rewind();
      explosion.play();
      for (Enemy en : enemies)
        en.vx = player.vx;
    }
  }

  public void draw() {
    update();
    playerLauncher.launcherAparatus();
    if (player.launched) {
      x += player.vx * -1;
      y += player.vx * -1;
    }
  }
}

public void playerLauncherUpdate() {
  playerLauncher.update();
  playerLauncher.draw();
}
//Alexander (eigenlijk alleen maar Luca)

ArrayList<PowerUps> savedPowerUps = new ArrayList<PowerUps>();

class PowerUps {
  PVector location, velocity, size;
  PImage powerSprite;
  boolean inUse = false;

  PowerUps(float x, float y, float w, float h, float vx, float vy, PImage sprite) {  
    location = new PVector(x, y);
    size = new PVector(w, h);
    velocity = new PVector(vx, vy);
    powerSprite = sprite;
  }

  public void update() {
    if (hitDetected(player, this))
      savedPowerUps.add(this);
    else
      location.add(velocity);
  }

  public boolean hitDetected(Player pl, PowerUps power) {
    boolean x = ((pl.x > power.location.x && pl.x < power.location.x + power.size.x)&&(pl.x + pl.w > power.location.x && pl.x + pl.w< power.location.x + power.size.x));
    boolean y = ((pl.y > power.location.y && pl.y < power.location.y + power.size.y)&&(pl.y + pl.w > power.location.y && pl.y + pl.w< power.location.y + power.size.y));
    return(x && y);
  }

  public void use() {
    //Nothing
  }

  public void draw() {
    image(powerSprite, location.x, location.y, size.x, size.y);
  }
}

class Speed extends PowerUps {
  String naam = "Speed"; 

  Speed(float x, float y, float w, float h, float vx, float vy, PImage sprite) {
    super(x, y, w, h, vx, vy, sprite);
  }

  public void use() {
    //Turbo
  }
}

class Snail extends PowerUps {
  String naam = "Snail" ; 

  Snail(float x, float y, float w, float h, float vx, float vy, PImage sprite) {
    super(x, y, w, h, vx, vy, sprite);
  }

  public void use() {
    //Turtle
  }
}

public void updatePower() {
  PowerUps power = savedPowerUps.get(0);
  if (keysPressed[ENTER] || power.inUse) {
    power.use();
  }
}
class Score {
  int score;
  float w;
  boolean scoreUpdated = false;

  Score(float scoreW) {
    w = scoreW;
  }

  public void update() {

    if (dead.status && !scoreUpdated) {
      score += (collectedCoins *10);
      scoreUpdated = true;
    }

    if (!dead.status && player.vy != 0) {
      score ++;
    }
  }

  public void draw () {
    update();
    fill(0, 0, 0, 120);
    rect(0, 0, w, 70);
    fill(255);
    textAlign(LEFT, TOP);
    textSize(20);
    text("Score: "+(int)score, 10, 10);
    text("Coins: "+(int)collectedCoins, 8, 40);
  }
}

public void setupScore() {
  score = new Score(scoreWidth);
}



// A reference to the processing sound engine
Minim minim = new Minim(this);

// SampleBank loads all samples in the data directory of your project
// so they can be triggered at any time in your game
class soundBank {

  HashMap<String, AudioSample> samples;
  AudioPlayer musicPlayer;

  // Constructor
  soundBank() {
    samples = new HashMap<String, AudioSample>();
    loadAllSamples();
  }

  // load the background music
  public void loadMusic(String musicFileName) {
    musicPlayer = minim.loadFile(musicFileName);
  }

  // play the background music
  public void playMusic() {
    musicPlayer.play();
  }

  // Add a new sample to the sound bank
  public void add(String sampleFileName) {
    AudioSample sample = minim.loadSample(sampleFileName);
    samples.put(sampleFileName, sample);    
    println(sampleFileName);
  }

  // trigger a loaded sample by fileName
  public void trigger(String sampleFileName) {
    //    if (!sampleFileName.endsWith(".wav") &&  samples.containsKey(sampleFileName + ".wav"))
    //      sampleFileName += ".wav";
    if (samples.containsKey(sampleFileName)) 
      samples.get(sampleFileName).trigger();
  }

  // trigger a loaded sample by index
  public void trigger(int sampleIndex) {
    Object [] keys = samples.keySet().toArray();
    if ((sampleIndex >= 0) && (sampleIndex < keys.length))
      trigger((String) keys[sampleIndex]);
  }

  // load all .wav files in the processing data directory
  public void loadAllSamples() {
    File dataFolder = new File(dataPath(""));
    File [] files = dataFolder.listFiles();

    for (File file : files)
      if (file.getName().toLowerCase().endsWith(".wav"))
        add(file.getName());
  }
}
  public void settings() {  fullScreen(P2D);  smooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "FowlyFlight_ConceptV1" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
